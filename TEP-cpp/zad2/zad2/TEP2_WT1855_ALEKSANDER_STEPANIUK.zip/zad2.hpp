#ifndef ZAD2_HPP
#define ZAD2_HPP

#include <iostream>

class CNumber {
private:
    bool negative;
    int* digits;
    int size;
public:
    CNumber(std::string strDigits);
    CNumber(int size, int vals);
    CNumber(long long val);
    CNumber() : size(0), digits(nullptr), negative(false) {};
    CNumber(const CNumber& pcOther);
    ~CNumber() { delete[] digits; }

    CNumber& operator=(const CNumber& pcOther);
    CNumber& operator=(const long long iValue);

    CNumber operator+(const CNumber& pcOther);
    CNumber operator+(long long iNewVal);

    CNumber operator-(const CNumber& pcOther);
    CNumber operator-(long long iNewVal);

    CNumber operator*(const CNumber& pcOther);
    CNumber operator*(long long iNewVal);

    CNumber operator/(const CNumber& pcOther);
    CNumber operator/(long long iNewVal);

    bool operator<(const CNumber& pcOther) const;
    bool operator<=(const CNumber& pcOther) const;

    bool operator>(const CNumber& pcOther) const;
    bool operator>=(const CNumber& pcOther) const;

    bool operator==(const CNumber& pcNewVal) const;
    bool operator==(long long iNewVal);

    bool operator!=(const CNumber& pcNewVal) const;
    bool operator!=(long long iNewVal);

    void myFixer(CNumber* pcOther); //usuwa zera z przodu oraz zamienia -0 na 0

    std::string toString() {
        std::string out = "";
        if (digits == nullptr) {
            out += "Not Definied";
        }
        else {
            if (negative) out += "-";
            for (int i = 0; i < size; i++) {
                out += (digits[i] + '0');
            }
        }
        return out;
    }
};

#endif