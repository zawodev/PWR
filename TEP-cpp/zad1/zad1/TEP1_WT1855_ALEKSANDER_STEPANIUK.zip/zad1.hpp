#ifndef ZAD1_HPP
#define ZAD1_HPP

void v_alloc_table_fill_34(int iSize);
void exercise_1(int iSize);

#endif