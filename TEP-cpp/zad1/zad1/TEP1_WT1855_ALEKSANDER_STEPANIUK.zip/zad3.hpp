#ifndef ZAD3_HPP
#define ZAD3_HPP

bool b_dealloc_table_2_dim(int** pi_table, int iSizeX, int iSizeY);
void exercise_3(int*** pi_table, int iSizeX, int iSizeY);

#endif
