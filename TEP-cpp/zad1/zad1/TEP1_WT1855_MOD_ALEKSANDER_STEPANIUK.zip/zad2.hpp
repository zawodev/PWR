#ifndef ZAD2_HPP
#define ZAD2_HPP

bool b_alloc_table_2_dim(int*** pi_table, int iSizeX, int iSizeY);
void exercise_2(int*** pi_table, int iSizeX, int iSizeY);

#endif
