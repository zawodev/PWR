#ifndef ZAD_MOD_HPP
#define ZAD_MOD_HPP

void printArray2D(int** table, int* sizeArray, int iSizeX);
void exercise_mod();
int** allocateIrregularArray2D(int* sizeArray, int iSizeX);
bool deallocateIrregularArray2D(int** array2D, int iSizeX);

#endif
