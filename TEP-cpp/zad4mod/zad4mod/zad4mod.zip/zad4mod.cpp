﻿#include <iostream>
#include "Array.hpp"

int main() {
    Array<int> A(3);
    //Array<std::string> B(3);

    std::cout << A[0];
    //std::cout << B[0];
}
