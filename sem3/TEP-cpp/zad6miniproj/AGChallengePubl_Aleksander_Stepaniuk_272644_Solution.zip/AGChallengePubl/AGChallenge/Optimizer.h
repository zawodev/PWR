#pragma once

#include "MyEvaluator.h"
#include "Evaluator.h"
#include "GeneticAlgorithmTwo.h"

//#include "GeneticAlgorithm.h" 
// kiedy� istnia� �adniej napisany z klasami pod miniprojekt, 
// ale dzia�a� wolniej wi�c na konkurs wysy�am ten (kod jest bardzo brzydki ale dzia�a w miare optymalnie)

#include <random>
#include <vector>

using namespace std;

class COptimizer {
public:
	COptimizer(CLFLnetEvaluator& cEvaluator);

	void vInitialize();
	void vRunIteration();

	vector<int>* pvGetCurrentBest() { 
		return GA.GetGlobalBestGenes();
	}

private:
	GeneticAlgorithmTwo GA;
	MyEvaluator myEvaluator;
};