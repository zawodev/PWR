#include "GeneticAlgorithmTwo.h"

#include <cfloat>
#include <iostream>
#include <windows.h>

#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <string.h>


using namespace std;


//USTAWIENIA SYMULACJI

//populacja
static int generationAmount = 1; //ilosc generacji
static int currentGenerationSize = 1024;  //aktualna liczba osobnikow w populacji

//vipy
static int vipAmount = 64; //ilosc najlepszych osobnikow ktorych przepisujemy bez zmian
static vector<int> vipAmountStates = { 0, 0, 0, 1, 1, 16, 64 }; //mozliwe wartosci vipAmount

//mutacja
static double mutationChance = .150; //szansa na mutacje w danym osobniku
static vector<double> mutationChanceStates = { .050, .150, .900 }; //mozliwe wartosci mutationChance

static double minMutationAmount = .001; //minimalna wartosc mutacji w lepszym osobniku
static double maxMutationAmount = .004; //maxymalna wartosc mutacji w gorszym osobniku

//krzy�owanie
static double crossoverPercent = .450; //procent osobnikow ktore krzyzujemy
static vector<double> crossoverPercentStates = { .300, .450, .600, .800, .900 }; //mozliwe wartosci crossoverPercent

//scoutowanie
static double scoutPercent = .000; //procent osobnikow ktore tworzymy losowo
static vector<double> scoutPercentStates = { .000, .001, .010, .100 }; //mozliwe wartosci scoutPercent

//usuwanie osobnikow
static double removeWorstOrRandomChance = 0.0; //[0.0, 1.0] usun najgorsze osobniki [0.0] lub losowe [1.0]
static vector<double> removeWorstOrRandomChanceStates = { 0.0, 0.05, 0.15, 0.35 }; //mozliwe wartosci removeWorstOrRandomChance

//zmiana strategii
bool changeStrategyBool = true; //czy zmienic strategie
int changeStrategyTreshhold = 25; //co ile nieskutecznych iteracji zmienic strategie
int changeStrategyCounter = 0; //licznik do czasu zmiany strategii

//USTAWIENIA SYMULACJI

vector<pair<double, vector<int>>> generation; //populacja
vector<pair<double, vector<int>>> vips; //najlepsze osobniki z poprzedniej generacji

void GeneticAlgorithmTwo::generateRandomGeneration(std::vector<std::pair<double, std::vector<int>>>& generation) {
	generation.clear();
	generation.reserve(currentGenerationSize);

	for (int i = 0; i < currentGenerationSize; ++i) {
		generation.push_back(generateRandomSpecimen());
	}
}
void GeneticAlgorithmTwo::updateBestSpecimen(std::vector<std::pair<double, std::vector<int>>>& gen) {
	//sprawdzamy czy najlepsze rozwiazanie z tej generacji jest lepsze od najlepszego z dotychczasowych rozwiazan
	pair<double, vector<int>> bestSpecimen = gen[0];
	if (bestSpecimen.first > globalBestFitness) {
		changeStrategyCounter = 0;

		globalBestGenes = bestSpecimen.second;
		globalBestFitness = bestSpecimen.first;
		localBestFitness = bestSpecimen.first;
	}
	else if (bestSpecimen.first > localBestFitness) {
		changeStrategyCounter = 0;
		localBestFitness = bestSpecimen.first;
	}
	else {
		changeStrategyCounter++;
		if (changeStrategyBool && changeStrategyCounter >= changeStrategyTreshhold) {
			changeStrategyCounter = 0;
			changeStrategy(gen);
		}
	}
}
void GeneticAlgorithmTwo::changeStrategy(std::vector<std::pair<double, std::vector<int>>>& gen) {

//strategia 1 - ma�a wariacja na zmiennych kontroluj�cych populacje

	//szansa na mutacje
	mutationChance = mutationChanceStates[iRand() % mutationChanceStates.size()];

	//procent krzyzowania
	crossoverPercent = crossoverPercentStates[iRand() % crossoverPercentStates.size()];

	//procent scoutowania
	scoutPercent = scoutPercentStates[iRand() % scoutPercentStates.size()];

	//ilosc najlepszych osobnikow ktore przepisujemy bez zmian
	vipAmount = vipAmountStates[iRand() % vipAmountStates.size()];

	//usun najgorsze osobniki lub losowe
	removeWorstOrRandomChance = removeWorstOrRandomChanceStates[iRand() % removeWorstOrRandomChanceStates.size()];

}
void GeneticAlgorithmTwo::Initialize() {
	//ustawiamy najlepsze rozwiazanie na najgorsze mozliwe
	localBestFitness = -DBL_MAX;
	globalBestFitness = -DBL_MAX;
	globalBestGenes.clear();

	generateRandomGeneration(generation);

	std::cout << "[autorem rozwiazania jest: Aleksander Stepaniuk PWr IST 272644, wszelkie prawa zastrzezone]" << std::endl;
	std::cout << "------------------ algorytm genetyczny uruchomiony, kalkulacje trwaja... ------------------" << std::endl;
}
void GeneticAlgorithmTwo::RunIteration() {
	//sortujemy rozwiazania od najlepszego do najgorszego
	quicksort(generation, 0, generation.size() - 1);

	//sprawdzamy czy najlepsze rozwiazanie z tej generacji jest lepsze od najlepszego z dotychczasowych rozwiazan
	updateBestSpecimen(generation);

	//liczymy nastepna generacje
	CalculateNextGeneration(generation);
}
void GeneticAlgorithmTwo::CalculateNextGeneration(vector<pair<double, vector<int>>>& generation) {

	//usuwanie rozwiazan zeby zrobic miejsce na krzyzowanie i scoutowanie
	int crossoverSize = (int)(currentGenerationSize * crossoverPercent);
	int scoutSize = (int)(currentGenerationSize * scoutPercent);
	int removalSize = crossoverSize + scoutSize;
	currentGenerationSize -= removalSize;

	for (int i = 0; i < removalSize; i++) {
		//usun przypadkowe rozwiazanie
		if (iRand() % 1000 < removeWorstOrRandomChance * 1000) generation.erase(generation.begin() + (iRand() % generation.size()));
		//usun najgorsze rozwiazanie
		else generation.pop_back();
	}

	//dodajemy losowych scoutow
	for (int i = 0; i < scoutSize; i++) {
		generation.push_back(generateRandomSpecimen());
	}

	//tworzymy nowe rozwi�zania krzy�uj�c najlepsze z poprzedniej generacji
	for (int i = 0; i < crossoverSize; i++) {
		pair<double, vector<int>> specimen;
		pair<double, vector<int>> parent1 = generation[iRand() % currentGenerationSize];
		pair<double, vector<int>> parent2 = generation[iRand() % currentGenerationSize]; //lub generation.size() jesli chcesz zeby dzieci tez sie rozmna�a�y od razu
		for (int j = 0; j < parent1.second.size(); j++) {
			if (iRand() % 2 == 0) specimen.second.push_back(parent1.second[j]);
			else specimen.second.push_back(parent2.second[j]);
		}
		evaluateSpecimen(specimen);
		generation.push_back(specimen);
	}

	currentGenerationSize += removalSize;

	//mutujemy wszystkie nowe rozwiazania (oprocz najlepszych vipow)
	for (int i = vipAmount; i < currentGenerationSize; i++) {
		if (iRand() % 1000 < mutationChance * 1000) {
			pair<double, vector<int>> specimen = generation[i];
			double specimenMutationAmount = minMutationAmount + ((double(i) / double(currentGenerationSize)) * (maxMutationAmount - minMutationAmount));
			for (int j = 0; j < specimen.second.size(); j++) {
				if (iRand() % 1000 < specimenMutationAmount * 1000) {
					specimen.second[j] = lRand(myEvaluator.iGetNumberOfValues(j));
				}
			}
			evaluateSpecimen(specimen);
			generation[i] = specimen;
		}
	}
}
void GeneticAlgorithmTwo::evaluateSpecimen(pair<double, vector<int>>& osobnik) {
	osobnik.first = myEvaluator.dEvaluate(&osobnik.second);
}

void GeneticAlgorithmTwo::quicksort(vector<pair<double, vector<int>>>& arr, int left, int right) {
	int i = left, j = right;
	pair<double, vector<int>> tmp;
	pair<double, vector<int>> pivot = arr[(left + right) / 2];

	while (i <= j) {
		while (arr[i].first > pivot.first) i++;
		while (arr[j].first < pivot.first) j--;
		if (i <= j) {
			tmp = arr[i];
			arr[i] = arr[j];
			arr[j] = tmp;
			i++;
			j--;
		}
	};

	if (left < j) quicksort(arr, left, j);
	if (i < right) quicksort(arr, i, right);
}
void GeneticAlgorithmTwo::v_fill_randomly(vector<int>& vSolution) {
	vSolution.resize((size_t)myEvaluator.iGetNumberOfBits());
	for (int ii = 0; ii < vSolution.size(); ii++) {
		vSolution.at(ii) = lRand(myEvaluator.iGetNumberOfValues(ii));
	}
}
pair<double, vector<int>> GeneticAlgorithmTwo::generateRandomSpecimen() {
	pair<double, vector<int>> specimen;
	v_fill_randomly(specimen.second);
	evaluateSpecimen(specimen);
	return specimen;
}