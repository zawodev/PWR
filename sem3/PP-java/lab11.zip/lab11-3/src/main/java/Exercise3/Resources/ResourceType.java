package Exercise3.Resources;

public enum ResourceType {
    WOOD_WASTE,
    WOOD,
    PAPER,
    DYE,
    INK,
    DYED_INK,
    SUDOKU,
    PLASTIC,
    SUDOKU_MAGAZINE,
}