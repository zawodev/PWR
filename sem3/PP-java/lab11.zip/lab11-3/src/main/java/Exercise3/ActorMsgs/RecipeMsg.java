package Exercise3.ActorMsgs;

import Exercise3.Tools.Recipe;

public record RecipeMsg (Recipe recipe) { }
