package Exercise3.ActorMsgs;

public record PrintActorMsg (boolean printAll) { }
