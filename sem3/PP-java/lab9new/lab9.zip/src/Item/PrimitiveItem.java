package Item;

import Point.*;

public abstract class PrimitiveItem extends Item {
    public PrimitiveItem (Point center) {
        super(center);
    }
}
